package MilitaryElite;

public enum MissionState {

    inProgress,
    Finished;
}
