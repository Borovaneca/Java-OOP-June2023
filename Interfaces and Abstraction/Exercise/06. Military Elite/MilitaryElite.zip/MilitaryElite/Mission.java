package MilitaryElite;

public interface Mission {

    String getMissionCodeName();

    State getState();
}
