package MilitaryElite;

public interface SpecialisedSoldier extends Private {

    Corp getCrop();
}
