package MilitaryElite;

public enum State {

    inProgress,
    finished
}
