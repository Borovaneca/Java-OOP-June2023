package MilitaryElite;

public interface Repair {

    String getPartName();

    int getHoursWorked();
}
