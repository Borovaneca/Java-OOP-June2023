package MilitaryElite;

public enum Corp {

    Airforces,
    Marines
}
