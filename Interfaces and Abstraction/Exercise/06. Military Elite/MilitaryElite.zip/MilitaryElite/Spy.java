package MilitaryElite;

public interface Spy {

    String getCodeNumber();
}
