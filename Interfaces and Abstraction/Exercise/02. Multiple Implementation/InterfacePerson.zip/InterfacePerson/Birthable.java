package InterfacePerson;

public interface Birthable {

    String getBirthDate();
}
