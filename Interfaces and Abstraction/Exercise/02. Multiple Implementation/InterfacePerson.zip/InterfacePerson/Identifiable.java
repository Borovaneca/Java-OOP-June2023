package InterfacePerson;

public interface Identifiable {

    String getId();
}
