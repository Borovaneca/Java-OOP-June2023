package InterfacePerson2;

public interface Person {

    String getName();

    int getAge();
}
