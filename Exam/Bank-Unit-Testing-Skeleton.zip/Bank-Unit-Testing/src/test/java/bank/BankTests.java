package bank;

public class BankTests {
}
