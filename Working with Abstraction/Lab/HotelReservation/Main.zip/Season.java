package WorkingWithAbstraction.Lab.HotelReservation;

public enum Season {
    Autumn("Autumn", 1),
    Spring("Spring", 2),
    Winter("Winter", 3),
    Summer("Summer", 4);


    private String name;
    private int coefficient;

    Season(String name, int coefficient) {
        this.name = name;
        this.coefficient = coefficient;
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(int coefficient) {
        this.coefficient = coefficient;
    }
}
