package WorkingWithAbstraction.Exercise.greedyTimes;

public enum ItemType {

    GOLD,
    GEM,
    CASH
}
