package Polymorphism.Exercise.Vehicle;

public interface Vehicle {

    void drive(double distance);

    void refuel(double liters);
}
