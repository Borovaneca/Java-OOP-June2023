package Polymorphism.Exercise.Vehicle;

public interface VehicleInterface {

    void drive(double distance);

    void refuel(double liters);
}
