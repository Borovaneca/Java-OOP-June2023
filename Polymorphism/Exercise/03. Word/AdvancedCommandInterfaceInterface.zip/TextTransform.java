package Polymorphism.Exercise.word;

public interface TextTransform {
    void invokeOn(StringBuilder text, int startIndex, int endIndex);
}
